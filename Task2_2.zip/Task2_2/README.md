# Swami Vivekananda Tribute Website

A beautiful, responsive tribute website dedicated to Swami Vivekananda, the great spiritual leader and philosopher who introduced Indian philosophy to the Western world.

## Features

- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern UI/UX**: Clean, elegant design with smooth animations
- **Interactive Timeline**: Visual representation of key life events
- **Achievement Showcase**: Highlighting major contributions and accomplishments
- **Animated Background**: Subtle particle animations for enhanced visual appeal
- **Smooth Navigation**: Fixed navigation bar with smooth scrolling

## Technologies Used

- HTML5
- CSS3 (with modern features like Grid, Flexbox, and CSS animations)
- Google Fonts (Playfair Display & Inter)
- Responsive design principles

## Sections

1. **Hero Section**: Introduction with key statistics
2. **Timeline**: Important life events from 1863-1902
3. **Achievements**: Major contributions including Chicago Parliament speech
4. **Biography**: Detailed life story and spiritual journey
5. **Legacy**: Lasting impact and continuing influence

## Getting Started

1. Clone this repository
2. Open `index.html` in your web browser
3. Enjoy learning about Swami Vivekananda's inspiring life!

## Live Demo

Open `index.html` in any modern web browser to view the website.

## Contributing

Feel free to contribute by:
- Adding more historical information
- Improving the design
- Adding new sections
- Fixing any issues

## License

This project is open source and available under the [MIT License](LICENSE).

---

*"Arise, awake, and stop not until the goal is reached." - Swami Vivekananda*